MACARONISMP WEBSITE — GRATIS

1. Open index.html om de website lokaal te bekijken.
2. Open index.html in Kladblok of een code-editor.
3. Zoek VUL-HIER-JE-IP-IN en vervang dit door je echte Minecraft-server-IP.
4. Zoek in de Discord-knop naar de tekst 'Vervang deze link door je Discord-uitnodiging' en vervang de href="#" door je Discord-uitnodigingslink.
5. Gratis online zetten met GitHub Pages:
   - Maak gratis een account op https://github.com/
   - Maak een nieuwe repository, bijvoorbeeld macaroni-website.
   - Upload index.html.
   - Ga naar Settings > Pages.
   - Kies Deploy from a branch, selecteer main en /(root), en klik Save.
   - GitHub toont je gratis website-adres zodra die klaar is.

Let op: leaderboards zijn voorlopig voorbeeldregels. Voor live gegevens moet je later een veilige koppeling/API met je Minecraft-server instellen. Zet nooit server tokens of geheime gegevens in deze website.
